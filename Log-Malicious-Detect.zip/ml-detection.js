// ============================================
// ML DETECTION MODULE
// TF-IDF, Clustering, and Pattern Matching
// ============================================

// Known attack patterns (regex-based detection)
const ATTACK_PATTERNS = [
    {
        pattern: /(union|select|insert|update|delete|drop|create|alter|exec|execute).*?(from|into|table)/gi,
        type: 'SQL Injection',
        severity: 'critical',
        description: 'Potential SQL injection attack detected'
    },
    {
        pattern: /<script[^>]*>.*?<\/script>/gi,
        type: 'XSS Attack',
        severity: 'critical',
        description: 'Cross-site scripting attempt detected'
    },
    {
        pattern: /(\.\.[\/\\]|etc[\/\\]passwd|windows[\/\\]system32)/gi,
        type: 'Path Traversal',
        severity: 'critical',
        description: 'Directory traversal attack detected'
    },
    {
        pattern: /(;|\||&&|`)(cat|ls|rm|chmod|wget|curl|nc|bash|sh|cmd|powershell)/gi,
        type: 'Command Injection',
        severity: 'critical',
        description: 'OS command injection attempt detected'
    },
    {
        pattern: /(eval|exec|system|passthru|shell_exec|base64_decode)\s*\(/gi,
        type: 'Code Injection',
        severity: 'critical',
        description: 'Remote code execution attempt detected'
    },
    {
        pattern: /((failed|invalid|incorrect|unauthorized).*?(login|password|authentication|access))|((login|password|authentication).*?failed)/gi,
        type: 'Failed Authentication',
        severity: 'warning',
        description: 'Multiple failed authentication attempts'
    },
    {
        pattern: /(sqlmap|nikto|nmap|metasploit|burp|acunetix|nessus|w3af)/gi,
        type: 'Security Scanner',
        severity: 'high',
        description: 'Known security scanning tool detected'
    },
    {
        pattern: /(port scan|network scan|vulnerability scan)/gi,
        type: 'Network Scanning',
        severity: 'high',
        description: 'Network scanning activity detected'
    },
    {
        pattern: /(brute\s*force|dictionary\s*attack|credential\s*stuffing)/gi,
        type: 'Brute Force',
        severity: 'high',
        description: 'Brute force attack detected'
    },
    {
        pattern: /\bDDOS\b|denial\s*of\s*service|flood\s*attack/gi,
        type: 'DoS Attack',
        severity: 'critical',
        description: 'Denial of service attack detected'
    }
];

// Stop words for TF-IDF (common words to ignore)
const STOP_WORDS = new Set([
    'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
    'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'been', 'be',
    'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'can', 'this', 'that', 'these', 'those'
]);

// ============================================
// MAIN ANALYSIS FUNCTION
// ============================================

function analyzeLogsWithML(logs, algorithm = 'kmeans', sensitivity = 7) {
    console.log(`🔍 Starting ML analysis with ${algorithm}, sensitivity: ${sensitivity}`);
    
    // Step 1: Pattern matching for known attacks
    const logsWithPatterns = detectKnownPatterns(logs);
    
    // Step 2: Extract text features for ML
    const messages = logsWithPatterns.map(log => log.message);
    
    // Step 3: TF-IDF feature extraction
    const tfidfResults = calculateTFIDF(messages);
    
    // Step 4: Clustering (unsupervised anomaly detection)
    const clusterResults = performClustering(
        tfidfResults.vectors,
        algorithm,
        sensitivity
    );
    
    // Step 5: Anomaly scoring
    const logsWithScores = scoreAnomalies(
        logsWithPatterns,
        clusterResults,
        tfidfResults
    );
    
    // Step 6: Generate analysis results
    const analysisResults = generateAnalysisReport(
        logsWithScores,
        tfidfResults,
        clusterResults
    );
    
    console.log('✅ Analysis complete');
    return analysisResults;
}

// ============================================
// PATTERN MATCHING
// ============================================

function detectKnownPatterns(logs) {
    const attackCounts = {};
    
    return logs.map(log => {
        let detectedPatterns = [];
        let maxSeverity = 0;
        
        // Check against all attack patterns
        ATTACK_PATTERNS.forEach(attackPattern => {
            if (attackPattern.pattern.test(log.message)) {
                detectedPatterns.push(attackPattern.type);
                attackCounts[attackPattern.type] = (attackCounts[attackPattern.type] || 0) + 1;
                
                // Calculate severity score
                const severityScore = attackPattern.severity === 'critical' ? 3 :
                                     attackPattern.severity === 'high' ? 2 : 1;
                maxSeverity = Math.max(maxSeverity, severityScore);
            }
        });
        
        return {
            ...log,
            detectedPatterns,
            patternScore: maxSeverity / 3, // Normalize to 0-1
            attackCounts
        };
    });
}

// ============================================
// TF-IDF CALCULATION
// ============================================

function calculateTFIDF(documents) {
    console.log('📊 Calculating TF-IDF features...');
    
    // Tokenize all documents
    const tokenizedDocs = documents.map(doc => tokenize(doc));
    
    // Build vocabulary
    const vocabulary = buildVocabulary(tokenizedDocs);
    
    // Calculate document frequencies
    const df = calculateDocumentFrequencies(tokenizedDocs, vocabulary);
    
    // Calculate TF-IDF vectors
    const vectors = tokenizedDocs.map(tokens => {
        return calculateTFIDFVector(tokens, vocabulary, df, documents.length);
    });
    
    // Get top keywords by TF-IDF score
    const keywords = getTopKeywords(vectors, vocabulary, 20);
    
    return {
        vectors,
        vocabulary,
        keywords
    };
}

function tokenize(text) {
    // Convert to lowercase, remove special chars, split on whitespace
    return text.toLowerCase()
        .replace(/[^a-z0-9\s]/g, ' ')
        .split(/\s+/)
        .filter(word => word.length > 2 && !STOP_WORDS.has(word));
}

function buildVocabulary(tokenizedDocs) {
    const vocabSet = new Set();
    tokenizedDocs.forEach(tokens => {
        tokens.forEach(token => vocabSet.add(token));
    });
    return Array.from(vocabSet);
}

function calculateDocumentFrequencies(tokenizedDocs, vocabulary) {
    const df = {};
    
    vocabulary.forEach(word => {
        df[word] = 0;
        tokenizedDocs.forEach(tokens => {
            if (tokens.includes(word)) {
                df[word]++;
            }
        });
    });
    
    return df;
}

function calculateTFIDFVector(tokens, vocabulary, df, numDocs) {
    const vector = new Array(vocabulary.length).fill(0);
    const tf = {};
    
    // Calculate term frequency
    tokens.forEach(token => {
        tf[token] = (tf[token] || 0) + 1;
    });
    
    // Calculate TF-IDF
    vocabulary.forEach((word, idx) => {
        if (tf[word]) {
            const termFreq = tf[word] / tokens.length;
            const invDocFreq = Math.log(numDocs / (df[word] + 1));
            vector[idx] = termFreq * invDocFreq;
        }
    });
    
    return vector;
}

function getTopKeywords(vectors, vocabulary, topN) {
    const avgScores = vocabulary.map((word, idx) => {
        const sum = vectors.reduce((acc, vec) => acc + vec[idx], 0);
        return {
            word,
            score: sum / vectors.length
        };
    });
    
    return avgScores
        .sort((a, b) => b.score - a.score)
        .slice(0, topN);
}

// ============================================
// CLUSTERING (Simplified K-Means)
// ============================================

function performClustering(vectors, algorithm, sensitivity) {
    console.log(`🎯 Performing ${algorithm} clustering...`);
    
    // Adjust number of clusters based on sensitivity
    const k = Math.max(2, Math.min(Math.ceil(vectors.length / 10), sensitivity));
    
    if (algorithm === 'kmeans') {
        return kMeansClustering(vectors, k);
    } else if (algorithm === 'dbscan') {
        return dbscanClustering(vectors, sensitivity);
    }
    
    return kMeansClustering(vectors, k);
}

function kMeansClustering(vectors, k) {
    if (vectors.length === 0) return { labels: [], centroids: [], clusters: [] };
    
    const maxIterations = 100;
    const dimensions = vectors[0].length;
    
    // Initialize centroids randomly
    let centroids = [];
    const usedIndices = new Set();
    for (let i = 0; i < k; i++) {
        let idx;
        do {
            idx = Math.floor(Math.random() * vectors.length);
        } while (usedIndices.has(idx));
        usedIndices.add(idx);
        centroids.push([...vectors[idx]]);
    }
    
    let labels = new Array(vectors.length).fill(0);
    let iterations = 0;
    let changed = true;
    
    while (changed && iterations < maxIterations) {
        changed = false;
        iterations++;
        
        // Assign points to nearest centroid
        for (let i = 0; i < vectors.length; i++) {
            let minDist = Infinity;
            let minIdx = 0;
            
            for (let j = 0; j < k; j++) {
                const dist = euclideanDistance(vectors[i], centroids[j]);
                if (dist < minDist) {
                    minDist = dist;
                    minIdx = j;
                }
            }
            
            if (labels[i] !== minIdx) {
                labels[i] = minIdx;
                changed = true;
            }
        }
        
        // Update centroids
        for (let j = 0; j < k; j++) {
            const clusterPoints = vectors.filter((_, idx) => labels[idx] === j);
            if (clusterPoints.length > 0) {
                centroids[j] = calculateMean(clusterPoints);
            }
        }
    }
    
    // Build cluster objects
    const clusters = [];
    for (let i = 0; i < k; i++) {
        const clusterIndices = labels.map((label, idx) => label === i ? idx : -1)
                                    .filter(idx => idx !== -1);
        clusters.push({
            id: i,
            size: clusterIndices.length,
            centroid: centroids[i],
            indices: clusterIndices,
            points: clusterIndices.map((idx, i) => ({
                x: idx,
                y: vectors[idx][0] || 0
            }))
        });
    }
    
    return { labels, centroids, clusters };
}

function dbscanClustering(vectors, sensitivity) {
    // Simplified DBSCAN implementation
    const eps = 0.5 / (sensitivity / 5); // Adjust epsilon based on sensitivity
    const minPts = Math.max(2, Math.floor(vectors.length / 20));
    
    const labels = new Array(vectors.length).fill(-1); // -1 = noise
    let clusterId = 0;
    
    for (let i = 0; i < vectors.length; i++) {
        if (labels[i] !== -1) continue; // Already processed
        
        const neighbors = findNeighbors(vectors, i, eps);
        
        if (neighbors.length < minPts) {
            labels[i] = -1; // Mark as noise
        } else {
            expandCluster(vectors, labels, i, neighbors, clusterId, eps, minPts);
            clusterId++;
        }
    }
    
    // Build cluster objects
    const clusters = [];
    for (let i = 0; i < clusterId; i++) {
        const clusterIndices = labels.map((label, idx) => label === i ? idx : -1)
                                    .filter(idx => idx !== -1);
        clusters.push({
            id: i,
            size: clusterIndices.length,
            indices: clusterIndices,
            points: clusterIndices.map((idx, i) => ({
                x: idx,
                y: vectors[idx][0] || 0
            }))
        });
    }
    
    return { labels, clusters, centroids: [] };
}

function findNeighbors(vectors, pointIdx, eps) {
    const neighbors = [];
    for (let i = 0; i < vectors.length; i++) {
        if (euclideanDistance(vectors[pointIdx], vectors[i]) <= eps) {
            neighbors.push(i);
        }
    }
    return neighbors;
}

function expandCluster(vectors, labels, pointIdx, neighbors, clusterId, eps, minPts) {
    labels[pointIdx] = clusterId;
    
    let i = 0;
    while (i < neighbors.length) {
        const neighborIdx = neighbors[i];
        
        if (labels[neighborIdx] === -1) {
            labels[neighborIdx] = clusterId;
        }
        
        if (labels[neighborIdx] === -1 || labels[neighborIdx] === clusterId) {
            labels[neighborIdx] = clusterId;
            const newNeighbors = findNeighbors(vectors, neighborIdx, eps);
            if (newNeighbors.length >= minPts) {
                neighbors.push(...newNeighbors);
            }
        }
        
        i++;
    }
}

function euclideanDistance(vec1, vec2) {
    let sum = 0;
    for (let i = 0; i < vec1.length; i++) {
        sum += Math.pow(vec1[i] - vec2[i], 2);
    }
    return Math.sqrt(sum);
}

function calculateMean(vectors) {
    if (vectors.length === 0) return [];
    
    const dimensions = vectors[0].length;
    const mean = new Array(dimensions).fill(0);
    
    vectors.forEach(vec => {
        vec.forEach((val, idx) => {
            mean[idx] += val;
        });
    });
    
    return mean.map(val => val / vectors.length);
}

// ============================================
// ANOMALY SCORING
// ============================================

function scoreAnomalies(logs, clusterResults, tfidfResults) {
    console.log('🎲 Scoring anomalies...');
    
    const { labels, centroids, clusters } = clusterResults;
    
    // Calculate cluster sizes
    const clusterSizes = {};
    labels.forEach(label => {
        clusterSizes[label] = (clusterSizes[label] || 0) + 1;
    });
    
    // Find outlier clusters (small clusters are often anomalies)
    const avgClusterSize = logs.length / clusters.length;
    
    return logs.map((log, idx) => {
        let score = log.patternScore || 0;
        
        // Factor 1: Pattern matching score (30% weight)
        score = score * 0.3;
        
        // Factor 2: Cluster size (smaller = more suspicious, 30% weight)
        const clusterLabel = labels[idx];
        const clusterSize = clusterSizes[clusterLabel] || 1;
        const clusterScore = 1 - (clusterSize / logs.length);
        score += clusterScore * 0.3;
        
        // Factor 3: Distance from centroid (30% weight)
        if (centroids.length > 0 && clusterLabel >= 0 && clusterLabel < centroids.length) {
            const dist = euclideanDistance(tfidfResults.vectors[idx], centroids[clusterLabel]);
            const maxDist = Math.sqrt(centroids[0].length); // Approximate max distance
            const distScore = Math.min(dist / maxDist, 1);
            score += distScore * 0.3;
        }
        
        // Factor 4: Severity boost (10% weight)
        if (log.severity === 'critical' || log.severity === 'error') {
            score += 0.1;
        }
        
        // Normalize to 0-1
        score = Math.min(Math.max(score, 0), 1);
        
        return {
            ...log,
            score,
            suspicious: score > 0.5,
            cluster: clusterLabel
        };
    });
}

// ============================================
// ANALYSIS REPORT GENERATION
// ============================================

function generateAnalysisReport(logs, tfidfResults, clusterResults) {
    console.log('📋 Generating analysis report...');
    
    // Extract attack indicators
    const attackIndicators = [];
    const attackTypes = {};
    
    logs.forEach(log => {
        if (log.detectedPatterns && log.detectedPatterns.length > 0) {
            log.detectedPatterns.forEach(pattern => {
                attackTypes[pattern] = (attackTypes[pattern] || 0) + 1;
            });
        }
    });
    
    Object.entries(attackTypes).forEach(([type, count]) => {
        const pattern = ATTACK_PATTERNS.find(p => p.type === type);
        attackIndicators.push({
            type,
            count,
            description: pattern ? pattern.description : 'Security threat detected'
        });
    });
    
    // Generate cluster summaries
    const clusterSummary = clusterResults.clusters.map(cluster => {
        const clusterLogs = logs.filter((_, idx) => 
            cluster.indices.includes(idx)
        );
        
        const suspiciousCount = clusterLogs.filter(log => log.suspicious).length;
        const avgScore = clusterLogs.reduce((sum, log) => sum + log.score, 0) / clusterLogs.length;
        
        return {
            size: cluster.size,
            suspiciousCount,
            description: suspiciousCount > cluster.size / 2 ?
                `High-risk cluster with ${suspiciousCount} suspicious logs` :
                `Normal cluster with ${cluster.size} logs`
        };
    });
    
    // Extract frequent patterns
    const patterns = [];
    const wordFreq = {};
    
    logs.forEach(log => {
        const tokens = tokenize(log.message);
        tokens.forEach(token => {
            wordFreq[token] = (wordFreq[token] || 0) + 1;
        });
    });
    
    Object.entries(wordFreq)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .forEach(([pattern, frequency]) => {
            patterns.push({ pattern, frequency });
        });
    
    // Generate timeline
    const timeline = {};
    logs.forEach(log => {
        if (log.timestamp && log.timestamp !== 'Unknown') {
            const hour = log.timestamp.substring(11, 13);
            timeline[hour] = (timeline[hour] || 0) + 1;
        }
    });
    
    return {
        logs,
        attackIndicators,
        clusterSummary,
        patterns,
        keywords: tfidfResults.keywords,
        clusters: clusterResults.clusters,
        timeline,
        stats: {
            total: logs.length,
            suspicious: logs.filter(l => l.suspicious).length,
            critical: logs.filter(l => l.severity === 'critical').length,
            errors: logs.filter(l => l.severity === 'error').length
        }
    };
}

console.log('✅ ML Detection module loaded successfully');