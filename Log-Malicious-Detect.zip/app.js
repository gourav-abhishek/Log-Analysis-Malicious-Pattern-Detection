// ============================================
// LOG ANALYSIS APPLICATION - MAIN LOGIC
// Browser-based log analyzer with ML detection
// ============================================

// Global state management (in-memory, no localStorage due to sandbox)
const AppState = {
    currentView: 'upload',
    logs: [],
    parsedLogs: [],
    analysisResults: null,
    charts: {},
    currentFilter: 'all'
};

// Sample log data embedded for offline use
const SAMPLE_LOGS = {
    normal: `[2025-10-28 08:15:23] INFO User login successful: user@example.com
[2025-10-28 08:15:45] INFO Database connection established
[2025-10-28 08:16:12] INFO Processing batch job #1234
[2025-10-28 08:17:33] INFO API request: GET /api/users
[2025-10-28 08:18:01] INFO Cache refreshed successfully
[2025-10-28 08:19:15] WARNING High memory usage: 78%
[2025-10-28 08:20:22] INFO User logout: user@example.com
[2025-10-28 08:21:34] INFO Scheduled backup started
[2025-10-28 08:22:45] INFO Email sent to admin@example.com
[2025-10-28 08:23:56] INFO System health check: OK
[2025-10-28 08:25:11] INFO File upload completed: report.pdf
[2025-10-28 08:26:23] INFO Session created for user_id: 5678
[2025-10-28 08:27:34] INFO Payment processed: $99.99
[2025-10-28 08:28:45] WARNING Slow query detected: 3.5s
[2025-10-28 08:29:56] INFO Notification sent to mobile device
[2025-10-28 08:31:07] INFO Cron job executed: cleanup_old_logs
[2025-10-28 08:32:18] INFO User password changed successfully
[2025-10-28 08:33:29] INFO Report generated: monthly_sales.xlsx
[2025-10-28 08:34:40] INFO API rate limit reset
[2025-10-28 08:35:51] INFO Background task completed`,

    malicious: `[2025-10-28 10:15:23] INFO User login attempt: admin@site.com
[2025-10-28 10:15:24] ERROR Login failed: admin - Invalid password
[2025-10-28 10:15:25] ERROR Login failed: admin - Invalid password
[2025-10-28 10:15:26] ERROR Login failed: admin - Invalid password
[2025-10-28 10:15:27] ERROR Login failed: admin - Invalid password
[2025-10-28 10:15:28] CRITICAL Brute force attack detected from IP: 192.168.1.100
[2025-10-28 10:16:45] WARNING SQL injection attempt: ' OR '1'='1
[2025-10-28 10:17:12] CRITICAL Malicious payload detected: SELECT * FROM users WHERE id=1 UNION SELECT password FROM admin--
[2025-10-28 10:18:33] WARNING XSS attempt: <script>alert('XSS')</script>
[2025-10-28 10:19:21] ERROR Path traversal detected: ../../etc/passwd
[2025-10-28 10:20:45] CRITICAL Command injection: ; cat /etc/shadow
[2025-10-28 10:21:56] WARNING Port scan detected from IP: 10.0.0.50
[2025-10-28 10:22:34] ERROR SSH brute force: Failed login attempt #47
[2025-10-28 10:23:12] WARNING Suspicious user agent: sqlmap/1.4.7
[2025-10-28 10:24:45] CRITICAL File inclusion attempt: include($_GET['file'])
[2025-10-28 10:25:23] ERROR Buffer overflow attempt detected
[2025-10-28 10:26:34] WARNING LDAP injection: *)(uid=*))(|(uid=*
[2025-10-28 10:27:45] CRITICAL Remote code execution: eval($_POST['cmd'])
[2025-10-28 10:28:56] ERROR Unauthorized API access attempt
[2025-10-28 10:29:12] WARNING Directory traversal: ../../../windows/system32
[2025-10-28 10:30:23] CRITICAL XXE attack: <!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
[2025-10-28 10:31:34] ERROR Session hijacking attempt detected
[2025-10-28 10:32:45] WARNING CSRF token mismatch - possible attack
[2025-10-28 10:33:56] CRITICAL Deserialization attack: O:8:"stdClass":1:{s:4:"code";s:6:"system";}
[2025-10-28 10:34:12] ERROR Malicious file upload: shell.php
[2025-10-28 10:35:23] WARNING Rate limit exceeded: 1000 requests in 60s
[2025-10-28 10:36:34] CRITICAL Privilege escalation attempt detected`
};

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Log Analysis Application Initialized');
    
    setupEventListeners();
    initializeCharts();
    updateStatus('Ready', 'success');
});

// ============================================
// EVENT LISTENERS SETUP
// ============================================

function setupEventListeners() {
    // File upload
    const fileInput = document.getElementById('fileInput');
    const dropZone = document.getElementById('dropZone');
    
    fileInput.addEventListener('change', handleFileSelect);
    
    dropZone.addEventListener('click', () => fileInput.click());
    
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });
    
    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });
    
    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFile(files[0]);
        }
    });
    
    // Sensitivity slider
    const sensitivity = document.getElementById('sensitivity');
    sensitivity.addEventListener('input', (e) => {
        const value = e.target.value;
        const label = e.target.nextElementSibling;
        if (value <= 3) label.textContent = 'Low';
        else if (value <= 7) label.textContent = 'Medium';
        else label.textContent = 'High';
    });
}

// ============================================
// VIEW SWITCHING
// ============================================

function switchView(viewName) {
    // Update navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`[data-view="${viewName}"]`).classList.add('active');
    
    // Update content
    document.querySelectorAll('.view-content').forEach(view => {
        view.classList.remove('active');
    });
    document.getElementById(`${viewName}View`).classList.add('active');
    
    AppState.currentView = viewName;
}

// ============================================
// FILE HANDLING
// ============================================

function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
        handleFile(file);
    }
}

function handleFile(file) {
    if (!file.name.endsWith('.log') && !file.name.endsWith('.txt')) {
        alert('Please upload a .log or .txt file');
        return;
    }
    
    updateStatus('Reading file...', 'info');
    
    const reader = new FileReader();
    reader.onload = (e) => {
        const content = e.target.result;
        processLogContent(content, file.name);
    };
    reader.onerror = () => {
        updateStatus('Error reading file', 'error');
    };
    reader.readAsText(file);
}

function loadSampleLog(type) {
    const content = SAMPLE_LOGS[type];
    const filename = type === 'normal' ? 'normal-syslog.txt' : 'malicious-log.txt';
    processLogContent(content, filename);
}

function processLogContent(content, filename) {
    showLoading(true);
    updateStatus('Processing logs...', 'info');
    
    // Simulate processing delay for UX
    setTimeout(() => {
        AppState.logs = content.split('\n').filter(line => line.trim());
        AppState.parsedLogs = parseLogLines(AppState.logs);
        
        displayLogs();
        updateLogStats();
        switchView('logs');
        
        updateStatus(`Loaded ${AppState.logs.length} logs from ${filename}`, 'success');
        showLoading(false);
    }, 500);
}

// ============================================
// LOG PARSING
// ============================================

function parseLogLines(lines) {
    return lines.map((line, index) => {
        // Parse log format: [timestamp] SEVERITY message
        const match = line.match(/\[(.*?)\]\s+(\w+)\s+(.+)/);
        
        if (match) {
            return {
                id: index,
                timestamp: match[1],
                severity: match[2].toLowerCase(),
                message: match[3],
                rawLine: line,
                suspicious: false,
                score: 0
            };
        }
        
        // Fallback for non-standard format
        return {
            id: index,
            timestamp: 'Unknown',
            severity: 'info',
            message: line,
            rawLine: line,
            suspicious: false,
            score: 0
        };
    });
}

// ============================================
// LOG DISPLAY
// ============================================

function displayLogs() {
    const logViewer = document.getElementById('logViewer');
    
    if (AppState.parsedLogs.length === 0) {
        logViewer.innerHTML = `
            <div class="text-center text-muted py-5">
                <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                <p class="mt-3">No logs to display</p>
            </div>
        `;
        return;
    }
    
    let filteredLogs = AppState.parsedLogs;
    
    if (AppState.currentFilter === 'suspicious') {
        filteredLogs = AppState.parsedLogs.filter(log => log.suspicious);
    } else if (AppState.currentFilter === 'errors') {
        filteredLogs = AppState.parsedLogs.filter(log => 
            log.severity === 'error' || log.severity === 'critical'
        );
    }
    
    logViewer.innerHTML = filteredLogs.map(log => {
        const severityClass = log.suspicious ? 'suspicious' : log.severity;
        const scoreHtml = log.suspicious ? 
            `<span class="log-score">${(log.score * 100).toFixed(0)}%</span>` : '';
        
        return `
            <div class="log-line ${severityClass}" data-id="${log.id}">
                <span class="log-timestamp">${log.timestamp}</span>
                <span class="log-severity">${log.severity}</span>
                <span class="log-message">${escapeHtml(log.message)}</span>
                ${scoreHtml}
            </div>
        `;
    }).join('');
}

function filterLogs(filterType) {
    AppState.currentFilter = filterType;
    displayLogs();
}

function updateLogStats() {
    const total = AppState.parsedLogs.length;
    const suspicious = AppState.parsedLogs.filter(log => log.suspicious).length;
    const errors = AppState.parsedLogs.filter(log => 
        log.severity === 'error' || log.severity === 'critical'
    ).length;
    const warnings = AppState.parsedLogs.filter(log => log.severity === 'warning').length;
    
    document.getElementById('totalLogs').textContent = total;
    document.getElementById('suspiciousLogs').textContent = suspicious;
    document.getElementById('errorLogs').textContent = errors;
    document.getElementById('warningLogs').textContent = warnings;
}

// ============================================
// ANALYSIS RUNNER
// ============================================

function runAnalysis() {
    if (AppState.parsedLogs.length === 0) {
        alert('Please load log files first');
        return;
    }
    
    showLoading(true);
    updateStatus('Running ML analysis...', 'info');
    
    const algorithm = document.getElementById('mlAlgorithm').value;
    const sensitivity = parseInt(document.getElementById('sensitivity').value);
    
    // Run analysis in next tick to allow UI update
    setTimeout(() => {
        try {
            // Call ML detection from ml-detection.js
            AppState.analysisResults = analyzeLogsWithML(AppState.parsedLogs, algorithm, sensitivity);
            
            // Update parsed logs with detection results
            AppState.parsedLogs = AppState.analysisResults.logs;
            
            // Update all views
            displayLogs();
            updateLogStats();
            updateDashboard();
            updateAnalysisView();
            
            updateStatus('Analysis complete', 'success');
            switchView('dashboard');
        } catch (error) {
            console.error('Analysis error:', error);
            updateStatus('Analysis failed', 'error');
        } finally {
            showLoading(false);
        }
    }, 100);
}

// ============================================
// DASHBOARD UPDATES
// ============================================

function updateDashboard() {
    if (!AppState.analysisResults) return;
    
    updateTimelineChart();
    updateSeverityChart();
    updateClusterChart();
    updateKeywords();
}

function initializeCharts() {
    // Initialize empty charts
    const timelineCtx = document.getElementById('timelineChart');
    const severityCtx = document.getElementById('severityChart');
    const clusterCtx = document.getElementById('clusterChart');
    
    if (timelineCtx) {
        AppState.charts.timeline = new Chart(timelineCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Events',
                    data: [],
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#e0e6ed' } }
                },
                scales: {
                    x: { ticks: { color: '#8f9bb3' }, grid: { color: 'rgba(0, 217, 255, 0.1)' } },
                    y: { ticks: { color: '#8f9bb3' }, grid: { color: 'rgba(0, 217, 255, 0.1)' } }
                }
            }
        });
    }
    
    if (severityCtx) {
        AppState.charts.severity = new Chart(severityCtx, {
            type: 'doughnut',
            data: {
                labels: ['Info', 'Warning', 'Error', 'Critical', 'Suspicious'],
                datasets: [{
                    data: [0, 0, 0, 0, 0],
                    backgroundColor: ['#82aaff', '#ffcb6b', '#ff5370', '#ff0000', '#7b2ff7']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#e0e6ed' } }
                }
            }
        });
    }
    
    if (clusterCtx) {
        AppState.charts.cluster = new Chart(clusterCtx, {
            type: 'scatter',
            data: {
                datasets: []
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#e0e6ed' } }
                },
                scales: {
                    x: { ticks: { color: '#8f9bb3' }, grid: { color: 'rgba(0, 217, 255, 0.1)' } },
                    y: { ticks: { color: '#8f9bb3' }, grid: { color: 'rgba(0, 217, 255, 0.1)' } }
                }
            }
        });
    }
}

function updateTimelineChart() {
    if (!AppState.charts.timeline || !AppState.analysisResults) return;
    
    const timeline = AppState.analysisResults.timeline || {};
    const labels = Object.keys(timeline).sort();
    const data = labels.map(label => timeline[label]);
    
    AppState.charts.timeline.data.labels = labels;
    AppState.charts.timeline.data.datasets[0].data = data;
    AppState.charts.timeline.update();
}

function updateSeverityChart() {
    if (!AppState.charts.severity || !AppState.parsedLogs) return;
    
    const counts = {
        info: 0,
        warning: 0,
        error: 0,
        critical: 0,
        suspicious: 0
    };
    
    AppState.parsedLogs.forEach(log => {
        if (log.suspicious) {
            counts.suspicious++;
        } else {
            counts[log.severity] = (counts[log.severity] || 0) + 1;
        }
    });
    
    AppState.charts.severity.data.datasets[0].data = [
        counts.info,
        counts.warning,
        counts.error,
        counts.critical,
        counts.suspicious
    ];
    AppState.charts.severity.update();
}

function updateClusterChart() {
    if (!AppState.charts.cluster || !AppState.analysisResults) return;
    
    const clusters = AppState.analysisResults.clusters || [];
    const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#5D878F', '#DB4545', '#D2BA4C'];
    
    const datasets = clusters.map((cluster, idx) => ({
        label: `Cluster ${idx}`,
        data: cluster.points || [],
        backgroundColor: colors[idx % colors.length],
        pointRadius: 5
    }));
    
    AppState.charts.cluster.data.datasets = datasets;
    AppState.charts.cluster.update();
}

function updateKeywords() {
    const container = document.getElementById('keywordsContainer');
    
    if (!AppState.analysisResults || !AppState.analysisResults.keywords) {
        container.innerHTML = '<p class="text-muted text-center py-4">No keywords detected</p>';
        return;
    }
    
    const keywords = AppState.analysisResults.keywords.slice(0, 15);
    
    container.innerHTML = keywords.map(kw => `
        <div class="keyword-badge">
            <span>${escapeHtml(kw.word)}</span>
            <span class="keyword-score">${kw.score.toFixed(2)}</span>
        </div>
    `).join('');
}

// ============================================
// ANALYSIS VIEW
// ============================================

function updateAnalysisView() {
    if (!AppState.analysisResults) return;
    
    updateAttackIndicators();
    updateClusterSummary();
    updatePatternSummary();
}

function updateAttackIndicators() {
    const container = document.getElementById('attackIndicators');
    const indicators = AppState.analysisResults.attackIndicators || [];
    
    if (indicators.length === 0) {
        container.innerHTML = '<p class="text-muted">No attack indicators detected</p>';
        return;
    }
    
    container.innerHTML = indicators.map(indicator => `
        <div class="indicator-item">
            <div class="indicator-header">
                <span class="indicator-type">${escapeHtml(indicator.type)}</span>
                <span class="indicator-count">${indicator.count} occurrence(s)</span>
            </div>
            <div class="indicator-description">${escapeHtml(indicator.description)}</div>
        </div>
    `).join('');
}

function updateClusterSummary() {
    const container = document.getElementById('clusterSummary');
    const clusters = AppState.analysisResults.clusterSummary || [];
    
    if (clusters.length === 0) {
        container.innerHTML = '<p class="text-muted">No clusters detected</p>';
        return;
    }
    
    container.innerHTML = clusters.map((cluster, idx) => `
        <div class="cluster-item">
            <div class="indicator-header">
                <span class="indicator-type">Cluster ${idx + 1}</span>
                <span class="indicator-count">${cluster.size} logs</span>
            </div>
            <div class="indicator-description">${escapeHtml(cluster.description)}</div>
        </div>
    `).join('');
}

function updatePatternSummary() {
    const container = document.getElementById('patternSummary');
    const patterns = AppState.analysisResults.patterns || [];
    
    if (patterns.length === 0) {
        container.innerHTML = '<p class="text-muted">No patterns detected</p>';
        return;
    }
    
    container.innerHTML = patterns.map(pattern => `
        <div class="pattern-item">
            <div class="indicator-header">
                <span class="indicator-type">${escapeHtml(pattern.pattern)}</span>
                <span class="indicator-count">${pattern.frequency} times</span>
            </div>
            <div class="indicator-description">Appears frequently in logs</div>
        </div>
    `).join('');
}

// ============================================
// EXPORT FUNCTIONALITY
// ============================================

function exportReport(format) {
    if (!AppState.analysisResults) {
        alert('Please run analysis first');
        return;
    }
    
    updateStatus(`Exporting ${format.toUpperCase()}...`, 'info');
    
    try {
        let content, filename, type;
        
        if (format === 'csv') {
            content = generateCSV();
            filename = 'log-analysis-report.csv';
            type = 'text/csv;charset=utf-8';
        } else if (format === 'json') {
            content = generateJSON();
            filename = 'log-analysis-report.json';
            type = 'application/json;charset=utf-8';
        } else if (format === 'txt') {
            content = generateTXT();
            filename = 'log-analysis-report.txt';
            type = 'text/plain;charset=utf-8';
        }
        
        const blob = new Blob([content], { type });
        saveAs(blob, filename);
        
        updateStatus('Export complete', 'success');
    } catch (error) {
        console.error('Export error:', error);
        updateStatus('Export failed', 'error');
    }
}

function generateCSV() {
    let csv = 'Timestamp,Severity,Message,Suspicious,Score\n';
    
    AppState.parsedLogs.forEach(log => {
        const row = [
            log.timestamp,
            log.severity,
            `"${log.message.replace(/"/g, '""')}"`,
            log.suspicious ? 'Yes' : 'No',
            (log.score * 100).toFixed(2)
        ];
        csv += row.join(',') + '\n';
    });
    
    return csv;
}

function generateJSON() {
    return JSON.stringify({
        metadata: {
            exportDate: new Date().toISOString(),
            totalLogs: AppState.parsedLogs.length,
            suspiciousLogs: AppState.parsedLogs.filter(l => l.suspicious).length
        },
        logs: AppState.parsedLogs,
        analysis: AppState.analysisResults
    }, null, 2);
}

function generateTXT() {
    let txt = '='.repeat(60) + '\n';
    txt += 'LOG ANALYSIS REPORT\n';
    txt += '='.repeat(60) + '\n\n';
    txt += `Export Date: ${new Date().toLocaleString()}\n`;
    txt += `Total Logs: ${AppState.parsedLogs.length}\n`;
    txt += `Suspicious Logs: ${AppState.parsedLogs.filter(l => l.suspicious).length}\n\n`;
    
    txt += 'ATTACK INDICATORS:\n';
    txt += '-'.repeat(60) + '\n';
    (AppState.analysisResults.attackIndicators || []).forEach(ind => {
        txt += `${ind.type}: ${ind.count} occurrence(s)\n`;
        txt += `  ${ind.description}\n\n`;
    });
    
    txt += '\nSUSPICIOUS LOGS:\n';
    txt += '-'.repeat(60) + '\n';
    AppState.parsedLogs.filter(l => l.suspicious).forEach(log => {
        txt += `[${log.timestamp}] ${log.severity.toUpperCase()} - Score: ${(log.score * 100).toFixed(0)}%\n`;
        txt += `  ${log.message}\n\n`;
    });
    
    return txt;
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (show) {
        overlay.classList.add('active');
    } else {
        overlay.classList.remove('active');
    }
}

function updateStatus(message, type) {
    const badge = document.getElementById('statusBadge');
    badge.innerHTML = `<i class="bi bi-circle-fill"></i> ${message}`;
    
    // Update color based on type
    badge.style.borderColor = type === 'success' ? '#00d9ff' : 
                              type === 'error' ? '#ff5370' : 
                              type === 'info' ? '#82aaff' : '#00d9ff';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

console.log('✅ App.js loaded successfully');